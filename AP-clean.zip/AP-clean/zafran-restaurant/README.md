# Zafran – Royal Mughlai Restaurant

Work in progress. `menu.html` is finished, but it depends on files that are not in the repository yet:

- [ ] `styles.css`
- [ ] `script.js` (loading screen, category filter, scroll reveal, mobile menu)
- [ ] `index.html`, `about.html`, `gallery.html`, `contact.html`
- [ ] Real phone number (placeholder `+919XXXXXXXXX` is used for WhatsApp and call links)
- [ ] Social media links (currently `#`)

Until these exist the page will render unstyled.
