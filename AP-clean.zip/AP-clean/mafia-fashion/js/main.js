// Mobile menu toggle
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

function setMenu(open) {
  hamburger.classList.toggle('active', open);
  navMenu.classList.toggle('active', open);
  hamburger.setAttribute('aria-expanded', String(open));
}

hamburger.addEventListener('click', () => setMenu(!navMenu.classList.contains('active')));

// Close the mobile menu when a link is clicked
document.querySelectorAll('.nav-menu a').forEach(link =>
  link.addEventListener('click', () => setMenu(false))
);

// Smooth scrolling for in-page anchors
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', event => {
    const id = anchor.getAttribute('href');
    const target = id.length > 1 ? document.querySelector(id) : null;
    if (target) {
      event.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// Navbar background on scroll
const navbar = document.querySelector('.navbar');
window.addEventListener('scroll', () => {
  navbar.style.background = window.scrollY > 100 ? 'rgb(0, 0, 0)' : 'rgba(0, 0, 0, 0.95)';
});
